/*************************************************************
  LED Control System using Blynk
 *************************************************************/

/* Fill-in information from Blynk Device Info here */
#define BLYNK_TEMPLATE_ID "TMPL6JKVzvMsj"
#define BLYNK_TEMPLATE_NAME "Quickstart Template"
#define BLYNK_AUTH_TOKEN "FzRTZS5ENRfLQSYpWHK6QrW305NPPpUC "

/* Comment this out to disable prints and save space */
#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>

// Your WiFi credentials.
char ssid[] = "Una";
char pass[] = "12345678";

// LED pin definition
const int LED_PIN = 5; // Using GPIO5 for LED

// LED control modes
enum LedMode
{
  LED_OFF,
  LED_ON,
  LED_AUTO
};

// Current LED mode
LedMode currentMode = LED_OFF;

// Variables for auto mode
unsigned long previousMillis = 0;
long interval = 1000; // Default interval is 1000ms
bool ledState = false;

// Interval levels
const long INTERVAL_FAST = 100;   // 100ms
const long INTERVAL_MEDIUM = 500; // 500ms
const long INTERVAL_SLOW = 1000;  // 1000ms

BlynkTimer timer;

// This function is called every time the Virtual Pin 0 state changes (Mode Selection)
BLYNK_WRITE(V4)
{
  int value = param.asInt();

  switch (value)
  {
  case 0: // OFF
    currentMode = LED_OFF;
    digitalWrite(LED_PIN, HIGH); // LED is active low
    break;
  case 1: // ON
    currentMode = LED_ON;
    digitalWrite(LED_PIN, LOW); // LED is active low
    break;
  case 2: // AUTO
    currentMode = LED_AUTO;
    break;
  }

  // Update status on V1
  Blynk.virtualWrite(V5, value);
}

// This function is called every time the Virtual Pin 2 state changes (Interval Control)
BLYNK_WRITE(V6)
{
  int value = param.asInt();
  
  // Set interval based on the received value
  switch (value) {
    case 0: // Fast
      interval = INTERVAL_FAST;
      break;
    case 1: // Medium
      interval = INTERVAL_MEDIUM;
      break;
    case 2: // Slow
      interval = INTERVAL_SLOW;
      break;
    default:
      interval = INTERVAL_SLOW; // Default to slow if invalid value
      break;
  }
}

// This function sends LED status every second to Virtual Pin 3
void myTimerEvent()
{
  bool actualState = !digitalRead(LED_PIN); // LED is active low, so we invert the reading
  Blynk.virtualWrite(V7, actualState);
}

void setup()
{
  // Debug console
  Serial.begin(115200);

  // Initialize LED pin as output
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH); // Ensure LED starts in OFF state (active low)

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  // Setup a function to be called every second
  timer.setInterval(1000L, myTimerEvent);
}

void loop()
{
  Blynk.run();
  timer.run();

  // Handle auto mode
  if (currentMode == LED_AUTO)
  {
    unsigned long currentMillis = millis();
    if (currentMillis - previousMillis >= interval)
    {
      previousMillis = currentMillis;
      ledState = !ledState;
      digitalWrite(LED_PIN, !ledState); // LED is active low
    }
  }
}